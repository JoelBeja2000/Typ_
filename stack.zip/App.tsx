import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Keyboard from './components/Keyboard';
import MacKeyboard from './components/MacKeyboard';
import FingerGuide from './components/FingerGuide';
import { KEY_TO_FINGER_MAP, SPACE_DATA } from './constants';
import { Language, TypingStats } from './types';
import { generatePracticePhrases } from './services/geminiService';

// --- MOTOR DE AUDIO TECHNO GENERATIVO ---
const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();

const playSuccessSound = (combo: number, isZen: boolean = false) => {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  
  // En modo Zen el tono sube sutilmente por cada carácter para crear una melodía
  const baseFreq = isZen ? 150 : 200;
  const mod = isZen ? (combo % 16) * 10 : combo * 15;
  
  osc.type = 'square';
  osc.frequency.setValueAtTime(baseFreq + mod, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(baseFreq * 2 + mod, audioCtx.currentTime + 0.05);
  
  gain.gain.setValueAtTime(isZen ? 0.04 : 0.08, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
  
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + 0.08);
};

const playErrorSound = () => {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(100, audioCtx.currentTime);
  osc.frequency.linearRampToValueAtTime(30, audioCtx.currentTime + 0.2);
  gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
  gain.gain.linearRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + 0.2);
};

// --- COMPONENTES UI AUXILIARES ---

interface AccordionItemProps {
  id: string;
  title: string;
  isExpanded: boolean;
  onToggle: (id: string) => void;
  children: React.ReactNode;
  icon: string;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ id, title, isExpanded, onToggle, children, icon }) => {
  return (
    <div className="flex flex-col border-b border-[var(--border-glass)]">
      <button 
        onClick={() => onToggle(id)} 
        className={`flex items-center justify-between py-5 px-2 transition-all duration-300 group ${isExpanded ? 'translate-x-1' : ''}`}
      >
        <div className="flex items-center gap-3">
          <i className={`fa ${icon} text-[10px] ${isExpanded ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]'}`}></i>
          <span className={`text-[10px] font-bold uppercase tracking-[0.2em] transition-colors ${isExpanded ? 'text-[var(--text-primary)]' : 'text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]'}`}>
            {title}
          </span>
        </div>
        <i className={`fa fa-chevron-right text-[8px] transition-transform duration-500 ${isExpanded ? 'rotate-90 text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`}></i>
      </button>
      <div className={`grid transition-all duration-500 ease-in-out ${isExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
        <div className="overflow-hidden">
          <div className="pb-6 pt-2 px-2">{children}</div>
        </div>
      </div>
    </div>
  );
};

const CompactSineWave: React.FC<{ active: boolean, combo: number, wpm: number }> = ({ active, combo, wpm }) => {
  const frequency = 1.5 + (wpm / 15);
  const amplitude = 4 + Math.min(combo * 3, 20);
  const speed = active ? (0.6 + (wpm / 40)) : 0.4;
  const opacity = active ? 0.6 : 0.2;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-xl transition-opacity duration-1000" style={{ opacity }}>
      <svg className="w-full h-full" viewBox="0 0 200 40" preserveAspectRatio="none">
        <path
          d="M0 20 Q 25 10, 50 20 T 100 20 T 150 20 T 200 20"
          fill="none"
          stroke="var(--accent-primary)"
          strokeWidth="1.2"
          strokeLinecap="round"
          className="transition-all duration-500"
        >
          <animate 
            attributeName="d" 
            dur={`${2.5 / speed}s`}
            repeatCount="indefinite"
            values={`
              M0 20 Q ${50/frequency} ${20-amplitude}, ${100/frequency} 20 T 200 20;
              M0 20 Q ${50/frequency} ${20+amplitude}, ${100/frequency} 20 T 200 20;
              M0 20 Q ${50/frequency} ${20-amplitude}, ${100/frequency} 20 T 200 20
            `}
          />
        </path>
      </svg>
    </div>
  );
};

const HiddenInput = React.memo(({ 
  inputRef, 
  onInput, 
  onCompositionStart, 
  onCompositionEnd, 
  onKeyDown,
  onBlur
}: {
  inputRef: React.RefObject<HTMLTextAreaElement | null>,
  onInput: (e: React.FormEvent<HTMLTextAreaElement>) => void,
  onCompositionStart: () => void,
  onCompositionEnd: (e: React.CompositionEvent<HTMLTextAreaElement>) => void,
  onKeyDown: (e: React.KeyboardEvent) => void,
  onBlur: () => void
}) => {
  return (
    <textarea
      ref={inputRef}
      onInput={onInput}
      onCompositionStart={onCompositionStart}
      onCompositionEnd={onCompositionEnd}
      onKeyDown={onKeyDown}
      onBlur={onBlur}
      className="absolute top-1/2 left-1/2 w-4 h-4 -translate-x-1/2 -translate-y-1/2 opacity-0 pointer-events-none z-[-1] caret-transparent cursor-none resize-none m-0 p-0 border-0 outline-none"
      autoComplete="off"
      autoCorrect="off"
      autoCapitalize="off"
      spellCheck="false"
      tabIndex={0}
    />
  );
});
HiddenInput.displayName = 'HiddenInput';

const hexToRgba = (hex: string, alpha: number) => {
  let c: any;
  if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)){
      c= hex.substring(1).split('');
      if(c.length== 3){
          c= [c[0], c[0], c[1], c[1], c[2], c[2]];
      }
      c= '0x'+c.join('');
      return 'rgba('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+','+alpha+')';
  }
  return `rgba(162, 173, 145, ${alpha})`;
}

type Palette = 'alpine' | 'ocean' | 'sunset' | 'amethyst' | 'custom';

const App: React.FC = () => {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [palette, setPalette] = useState<Palette>('alpine');
  const [customColor, setCustomColor] = useState('#A2AD91');
  
  const [language, setLanguage] = useState<Language>('es');
  const [focus, setFocus] = useState('Básico');
  const [phrases, setPhrases] = useState<string[]>([]);
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [typedText, setTypedText] = useState('');
  const [activeKey, setActiveKey] = useState('');
  const [stats, setStats] = useState<TypingStats>({ wpm: 0, accuracy: 100, mistakes: 0, totalChars: 0 });
  const [combo, setCombo] = useState(0);
  const [wordHasMistake, setWordHasMistake] = useState(false);
  
  const [startTime, setStartTime] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFinished, setIsFinished] = useState(false);
  const [showLeftSidebar, setShowLeftSidebar] = useState(false);
  const [showRightSidebar, setShowRightSidebar] = useState(false);
  const [keyboardType, setKeyboardType] = useState<'standard' | 'mac'>('mac');
  const [expandedLeftCat, setExpandedLeftCat] = useState<string | null>('config');
  const [showZones, setShowZones] = useState(false);
  const [isMusicEnabled, setIsMusicEnabled] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);
  
  const [isComposingState, setIsComposingState] = useState(false);
  
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const colorInputRef = useRef<HTMLInputElement>(null);
  const isComposingRef = useRef(false); 
  const lastProcessedText = useRef('');

  const musicIntervalRef = useRef<number | null>(null);
  const stepRef = useRef(0);

  const normalizedTypedText = useMemo(() => typedText.normalize('NFC'), [typedText]);
  const currentPhrase = useMemo(() => (phrases[phraseIndex] || '').normalize('NFC'), [phrases, phraseIndex]);
  const currentPos = Math.min(normalizedTypedText.length, currentPhrase.length);
  const targetChar = currentPhrase[currentPos] || '';
  const targetKeyData = KEY_TO_FINGER_MAP[targetChar.toLowerCase()] || (targetChar === ' ' ? SPACE_DATA : undefined);

  const currentWordInfo = useMemo(() => {
    if (!currentPhrase) return { word: '', userTypedSlice: '' };
    const lastSpaceBefore = currentPhrase.lastIndexOf(' ', currentPos - 1);
    const nextSpaceAfter = currentPhrase.indexOf(' ', currentPos);
    const start = lastSpaceBefore === -1 ? 0 : lastSpaceBefore + 1;
    const end = nextSpaceAfter === -1 ? currentPhrase.length : nextSpaceAfter;
    const word = currentPhrase.substring(start, end);
    const userTypedSlice = normalizedTypedText.substring(start, normalizedTypedText.length);
    return { word, userTypedSlice };
  }, [currentPhrase, currentPos, normalizedTypedText]);

  const playKick = useCallback(() => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.3);
  }, []);

  const playHiHat = useCallback(() => {
    const noise = audioCtx.createBufferSource();
    const bufferSize = audioCtx.sampleRate * 0.05;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) output[i] = Math.random() * 2 - 1;
    noise.buffer = buffer;
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 8000;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);
    noise.start();
  }, []);

  const playAcidBass = useCallback((noteFreq: number, comboVal: number) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(noteFreq, audioCtx.currentTime);
    filter.type = 'lowpass';
    const baseCutoff = 400 + (Math.min(comboVal, 20) * 100);
    filter.frequency.setValueAtTime(baseCutoff, audioCtx.currentTime);
    filter.Q.value = 15;
    gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.2);
  }, []);

  useEffect(() => {
    if (isMusicEnabled && startTime && !isFinished) {
      const bpm = 128;
      const stepTime = (60 / bpm) / 4;
      musicIntervalRef.current = window.setInterval(() => {
        const step = stepRef.current % 16;
        if (step % 4 === 0) playKick();
        if (combo > 2 && (step === 2 || step === 6 || step === 10 || step === 14)) playHiHat();
        if (combo > 8 && step % 2 === 0) {
          const notes = [55, 65, 73, 82];
          const note = notes[Math.floor(Math.random() * notes.length)];
          playAcidBass(note, combo);
        }
        stepRef.current++;
      }, stepTime * 1000);
      return () => { if (musicIntervalRef.current) clearInterval(musicIntervalRef.current); };
    } else { if (musicIntervalRef.current) clearInterval(musicIntervalRef.current); }
  }, [isMusicEnabled, startTime, isFinished, combo, playKick, playHiHat, playAcidBass]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-palette', palette);
    if (palette === 'custom') {
      document.documentElement.style.setProperty('--accent-primary', customColor);
      document.documentElement.style.setProperty('--accent-glow', hexToRgba(customColor, 0.4));
    } else {
      document.documentElement.style.removeProperty('--accent-primary');
      document.documentElement.style.removeProperty('--accent-glow');
    }
  }, [theme, palette, customColor]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  const cyclePalette = () => {
    const palettes: Palette[] = ['alpine', 'ocean', 'sunset', 'amethyst'];
    setPalette(prev => prev === 'custom' ? palettes[0] : palettes[(palettes.indexOf(prev) + 1) % palettes.length]);
  };

  useEffect(() => {
    const keepFocus = () => {
      if (!showLeftSidebar && !showRightSidebar && !isLoading && !isFinished && document.activeElement !== colorInputRef.current) {
        setTimeout(() => inputRef.current?.focus(), 10);
      }
    };
    window.addEventListener('click', keepFocus);
    window.addEventListener('focus', keepFocus);
    return () => {
      window.removeEventListener('click', keepFocus);
      window.removeEventListener('focus', keepFocus);
    };
  }, [showLeftSidebar, showRightSidebar, isLoading, isFinished]);

  useEffect(() => {
    const init = async () => {
      setIsLoading(true);
      const newPhrases = await generatePracticePhrases(language, focus);
      setPhrases(newPhrases.map(p => p.normalize('NFC')));
      setTypedText(''); lastProcessedText.current = ''; setPhraseIndex(0); setCombo(0); setWordHasMistake(false);
      if (inputRef.current) inputRef.current.value = '';
      setIsLoading(false);
    };
    init();
  }, [language, focus]);

  // Lógica de procesamiento de caracteres mejorada para el FLOW
  useEffect(() => {
    const current = normalizedTypedText;
    const previous = lastProcessedText.current.normalize('NFC');
    if (current === previous || isComposingRef.current) return;
    if (!startTime && current.length > 0) setStartTime(Date.now());

    if (current.length > previous.length) {
      const idx = current.length - 1;
      const tChar = currentPhrase[idx];
      const typedChar = current[idx];
      
      if (idx < currentPhrase.length) {
         if (!isZenMode && typedChar !== tChar) {
            setWordHasMistake(true); setCombo(0); playErrorSound();
            setStats(prev => ({
              ...prev, mistakes: prev.mistakes + 1, totalChars: prev.totalChars + 1,
              accuracy: Math.round(((prev.totalChars + 1 - (prev.mistakes + 1)) / (prev.totalChars + 1)) * 100)
            }));
         } else {
            // Acierto (o auto-validación Zen)
            setStats(prev => ({
              ...prev, totalChars: prev.totalChars + 1,
              accuracy: Math.round(((prev.totalChars + 1 - prev.mistakes) / (prev.totalChars + 1)) * 100)
            }));
            
            // Sonido reactivo por CADA carácter en Zen para mantener el ritmo
            if (isZenMode) {
              setCombo(c => c + 1);
              playSuccessSound(combo + 1, true);
            } else if (typedChar === ' ' || idx === currentPhrase.length - 1) {
              if (!wordHasMistake) { 
                setCombo(c => c + 1); 
                playSuccessSound(combo + 1, false); 
              }
              setWordHasMistake(false);
            }
         }
      }
    }
    
    lastProcessedText.current = current;

    // Transición de frase instantánea para el FLOW
    if (current === currentPhrase && currentPhrase.length > 0) {
      if (phraseIndex < phrases.length - 1) {
        // En modo ZEN el salto es inmediato, en modo normal mantenemos el pequeñísimo micro-tiempo para feedback visual
        const delay = isZenMode ? 0 : 50; 
        setTimeout(() => {
          setPhraseIndex(prev => prev + 1); 
          setTypedText(''); 
          lastProcessedText.current = '';
          if (inputRef.current) inputRef.current.value = '';
        }, delay);
      } else {
        setIsFinished(true);
      }
    }
  }, [normalizedTypedText, currentPhrase, phraseIndex, phrases.length, startTime, wordHasMistake, combo, isZenMode]);

  const handleInput = useCallback((e: React.FormEvent<HTMLTextAreaElement>) => {
    let val = e.currentTarget.value.normalize('NFC');
    
    // MODO ZEN: Se traga CUALQUIER input y lo mapea a la secuencia correcta
    if (isZenMode) {
      const phrase = phrases[phraseIndex] || '';
      if (val.length <= phrase.length) {
        val = phrase.substring(0, val.length);
        e.currentTarget.value = val;
      } else {
        // Si ya terminó la frase pero sigue escribiendo, ignoramos el extra
        val = phrase;
        e.currentTarget.value = val;
      }
    }
    
    setTypedText(val);
  }, [isZenMode, phrases, phraseIndex]);

  const handleCompositionStart = useCallback(() => { isComposingRef.current = true; setIsComposingState(true); }, []);
  const handleCompositionEnd = useCallback((e: React.CompositionEvent<HTMLTextAreaElement>) => {
    isComposingRef.current = false; setIsComposingState(false);
    let val = e.currentTarget.value.normalize('NFC');
    
    if (isZenMode) {
      const phrase = phrases[phraseIndex] || '';
      if (val.length <= phrase.length) {
        val = phrase.substring(0, val.length);
        e.currentTarget.value = val;
      }
    }
    
    setTypedText(val);
  }, [isZenMode, phrases, phraseIndex]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    setActiveKey(e.key);
    setTimeout(() => setActiveKey(''), 150);
    if (audioCtx.state === 'suspended') audioCtx.resume();
  }, []);

  useEffect(() => {
    if (startTime && !isFinished) {
      const interval = setInterval(() => {
        const timeElapsed = (Date.now() - startTime) / 60000;
        let correctChars = 0;
        const current = normalizedTypedText;
        for(let i=0; i<current.length; i++) if(current[i] === currentPhrase[i]) correctChars++;
        setStats(prev => ({ ...prev, wpm: Math.round((correctChars / 5) / (timeElapsed || 0.001)) || 0 }));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [startTime, isFinished, normalizedTypedText, currentPhrase]);

  const restart = async () => {
    setTypedText(''); lastProcessedText.current = ''; setPhraseIndex(0); setCombo(0); setWordHasMistake(false);
    if (inputRef.current) inputRef.current.value = '';
    setStats({ wpm: 0, accuracy: 100, mistakes: 0, totalChars: 0 });
    setStartTime(null); setIsFinished(false); setIsLoading(true);
    const newPhrases = await generatePracticePhrases(language, focus);
    setPhrases(newPhrases.map(p => p.normalize('NFC')));
    setIsLoading(false);
    setTimeout(() => inputRef.current?.focus(), 10);
  };

  const setSimpleWarmup = () => {
    setIsLoading(true);
    const warmupPhrases = ["a a a a a a a a", "j j j j j j j j", "f f f f f f f f", "d d d d d d d d", "k k k k k k k k"];
    setPhrases(warmupPhrases); setTypedText(''); lastProcessedText.current = ''; setPhraseIndex(0); setCombo(0); setWordHasMistake(false); setStartTime(null); setStats({ wpm: 0, accuracy: 100, mistakes: 0, totalChars: 0 });
    setIsFinished(false); setIsLoading(false); setShowLeftSidebar(false);
    setTimeout(() => inputRef.current?.focus(), 10);
  };

  const getBtnClass = (active: boolean) => `w-full p-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300 border flex items-center justify-between group ${active ? 'bg-[var(--accent-primary)]/10 border-[var(--accent-primary)] text-[var(--accent-primary)] shadow-[0_0_15px_var(--accent-glow)]' : 'bg-transparent border-[var(--border-glass)] text-[var(--text-secondary)] hover:border-[var(--text-primary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-glass)]'}`;

  return (
    <div className="min-h-screen relative flex flex-row items-stretch overflow-hidden bg-[var(--bg-app)] transition-colors duration-500">
      <HiddenInput inputRef={inputRef} onInput={handleInput} onCompositionStart={handleCompositionStart} onCompositionEnd={handleCompositionEnd} onKeyDown={handleKeyDown} onBlur={() => setIsComposingState(false)} />
      <input type="color" ref={colorInputRef} onChange={(e) => { setCustomColor(e.target.value); setPalette('custom'); }} value={customColor} className="fixed opacity-0 pointer-events-none -z-10" />

      <button onClick={() => setShowLeftSidebar(true)} className={`fixed left-0 top-1/2 -translate-y-1/2 z-[1000] h-16 w-8 flex items-center justify-center bg-[var(--bg-glass)] backdrop-blur-xl border border-[var(--border-glass)] border-l-0 rounded-r-2xl transition-all duration-500 group ${showLeftSidebar ? 'translate-x-[-100%] opacity-0' : 'opacity-100'}`}><i className="fa fa-chevron-right text-[10px] text-[var(--text-secondary)]"></i></button>
      <button onClick={() => setShowRightSidebar(true)} className={`fixed right-0 top-1/2 -translate-y-1/2 z-[1000] h-16 w-8 flex items-center justify-center bg-[var(--bg-glass)] backdrop-blur-xl border border-[var(--border-glass)] border-r-0 rounded-l-2xl transition-all duration-500 group ${showRightSidebar ? 'translate-x-[100%] opacity-0' : 'opacity-100'}`}><i className="fa fa-chevron-left text-[10px] text-[var(--text-secondary)]"></i></button>

      <div className={`fixed inset-0 z-[2000] bg-black/60 backdrop-blur-md transition-all duration-500 ${(showLeftSidebar || showRightSidebar) ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => { setShowLeftSidebar(false); setShowRightSidebar(false); }} />

      <aside className={`fixed top-0 left-0 h-full w-[400px] z-[2001] bg-[var(--bg-glass-strong)] backdrop-blur-3xl border-r border-[var(--border-glass)] p-8 transition-all duration-500 transform ${showLeftSidebar ? 'translate-x-0' : '-translate-x-full'} overflow-y-auto`}>
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-4"><div className="w-14 h-10 flex items-center justify-center rounded-xl border border-[var(--accent-primary)] text-[var(--accent-primary)] bg-[var(--accent-primary)]/10 font-black text-xl shadow-[0_0_15px_var(--accent-glow)]">Typ_</div><h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-[var(--text-primary)]">System_Core</h2></div>
          <button onClick={() => setShowLeftSidebar(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-[var(--bg-glass)] text-[var(--text-secondary)]"><i className="fa fa-close"></i></button>
        </div>
        <div className="mb-8">
           <button onClick={setSimpleWarmup} className="w-full py-5 rounded-[1.5rem] bg-[var(--accent-primary)] text-[var(--bg-app)] font-black uppercase tracking-[0.2em] shadow-[0_10px_30px_var(--accent-glow)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 group">
              <i className="fa fa-bolt group-hover:animate-bounce"></i>
              <span>Calentamiento "A A A"</span>
           </button>
           <p className="mt-4 text-[8px] text-[var(--text-ghost)] uppercase tracking-widest text-center px-4 leading-relaxed">Práctica de teclas base para entrar en calor.</p>
        </div>
        <AccordionItem id="config" title="Configuración" icon="fa-sliders" isExpanded={expandedLeftCat === 'config'} onToggle={setExpandedLeftCat}>
          <div className="space-y-4">
            <button onClick={() => setLanguage('es')} className={getBtnClass(language === 'es')}><span>Español</span> <span>🇪🇸</span></button>
            <button onClick={() => setLanguage('en')} className={getBtnClass(language === 'en')}><span>English</span> <span>🇺🇸</span></button>
            <div className="h-[1px] bg-[var(--border-glass)] my-2" />
            <button onClick={() => setFocus('Básico')} className={getBtnClass(focus === 'Básico')}><span>Básico</span></button>
            <button onClick={() => setFocus('Programación')} className={getBtnClass(focus === 'Programación')}><span>Programación</span></button>
            <button onClick={() => setFocus('Teclas Raras')} className={getBtnClass(focus === 'Teclas Raras')}><span>Teclas Raras</span></button>
          </div>
        </AccordionItem>
      </aside>

      <aside className={`fixed top-0 right-0 h-full w-[450px] z-[2001] bg-[var(--bg-glass-strong)] backdrop-blur-3xl border-l border-[var(--border-glass)] p-8 transition-all duration-500 transform ${showRightSidebar ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between mb-12"><h2 className="text-[10px] font-black uppercase tracking-[0.5em] text-[var(--accent-primary)]">Guía Técnica</h2><button onClick={() => setShowRightSidebar(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-[var(--bg-glass)] text-[var(--text-secondary)]"><i className="fa fa-close"></i></button></div>
        <FingerGuide targetKeyData={targetKeyData} />
      </aside>

      <main className="flex-grow flex flex-col items-center justify-center p-8 transition-all duration-500" style={{ opacity: (showLeftSidebar || showRightSidebar) ? 0.3 : 1 }}>
        <div className="w-full max-w-5xl flex flex-col items-center gap-8">
          <div className="w-full bg-[var(--bg-glass)] backdrop-blur-xl border border-[var(--border-glass)] rounded-[1.5rem] p-10 md:p-14 min-h-[180px] flex flex-col justify-center relative overflow-hidden">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="w-8 h-8 border-2 border-[var(--accent-primary)] border-t-transparent rounded-full animate-spin"></div>
                <p className="text-[var(--text-secondary)] font-mono text-[8px] uppercase tracking-[0.4em]">Iniciando_Motor...</p>
              </div>
            ) : isFinished ? (
              <div className="text-center animate-in zoom-in duration-700">
                <h2 className="text-3xl font-black text-[var(--text-primary)] mb-6 font-mono tracking-tighter">OBJETIVO_CUMPLIDO</h2>
                <button onClick={restart} className="group px-10 py-4 rounded-xl border border-[var(--accent-primary)] text-[var(--accent-primary)] font-black uppercase tracking-widest hover:bg-[var(--accent-primary)]/10 hover:shadow-[0_0_30px_var(--accent-glow)] transition-all">Siguiente Protocolo</button>
              </div>
            ) : (
              <div className="font-mono text-2xl md:text-3xl relative select-none">
                <div className="text-[var(--text-ghost)] whitespace-pre-wrap leading-relaxed">
                  {currentPhrase.split('').map((char, i) => {
                    let color = "text-[var(--text-ghost)]"; 
                    if (i < normalizedTypedText.length) {
                      if (isComposingState && i === normalizedTypedText.length - 1) color = "text-yellow-400 border-b-2 border-yellow-400/50";
                      else color = normalizedTypedText[i] === char ? "text-[var(--accent-primary)]" : "text-red-400 bg-red-500/10 border-b-2 border-red-500/30";
                    }
                    return <span key={i} className={`${color} transition-all inline-block`}>{char === ' ' ? '\u00A0' : char}{i === normalizedTypedText.length && <span className="absolute left-0 bottom-[-4px] w-full h-[3px] bg-[var(--accent-primary)] animate-pulse shadow-[0_0_15px_var(--accent-primary)]" />}</span>;
                  })}
                </div>
              </div>
            )}
          </div>

          {!isLoading && !isFinished && (
            <div className="bg-[var(--bg-floating)] backdrop-blur-xl border border-[var(--border-strong)] rounded-[1.5rem] px-12 h-24 flex items-center justify-center min-w-[360px] shadow-2xl">
               <div className="relative font-mono text-3xl flex items-center h-full min-w-[200px]">
                  <div className="absolute inset-0 text-[var(--text-ghost)] whitespace-pre flex items-center justify-start pointer-events-none">{currentWordInfo.word}</div>
                  <div className="relative flex items-center whitespace-pre h-full">
                    {currentWordInfo.userTypedSlice.split('').map((userChar, idx) => {
                      const correct = userChar === (currentWordInfo.word[idx] || '');
                      const color = (isComposingState && idx === currentWordInfo.userTypedSlice.length - 1) ? "text-yellow-400" : (correct ? 'text-[var(--accent-primary)]' : 'text-red-400 bg-red-500/10 border-b-2 border-red-500/30');
                      return <span key={idx} className={`relative inline-block ${color}`}>{userChar === ' ' ? '\u00A0' : userChar}</span>;
                    })}
                    <span className="inline-block w-0.5 h-10 bg-[var(--accent-primary)] shadow-[0_0_15px_var(--accent-primary)] animate-pulse rounded-full ml-[-1px]" />
                  </div>
               </div>
            </div>
          )}

          <div className="w-full relative flex flex-col items-center">
            <div className="w-full bg-[var(--bg-glass)] backdrop-blur-xl border border-[var(--border-glass)] rounded-[1.5rem] p-10 pt-20 flex justify-center shadow-2xl relative">
              
              <div className="absolute top-6 left-6 flex gap-2 z-30">
                <button onClick={restart} className="h-11 w-11 flex items-center justify-center bg-[var(--bg-glass)] border border-[var(--border-strong)] rounded-2xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all" title="Reiniciar"><i className="fa fa-refresh"></i></button>
                <button onClick={() => setIsZenMode(!isZenMode)} className={`h-11 px-4 flex items-center justify-center border rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all group ${isZenMode ? 'bg-[var(--accent-primary)] text-[var(--bg-app)] border-[var(--accent-primary)] shadow-[0_0_15px_var(--accent-glow)]' : 'bg-[var(--bg-glass)] text-[var(--text-secondary)] border-[var(--border-strong)]'}`} title="Modo Swallow (Traga-todo)">
                  <i className={`fa ${isZenMode ? 'fa-bolt' : 'fa-shield'} mr-2 ${isZenMode ? 'animate-pulse' : ''}`}></i>
                  MODO ZEN {isZenMode ? 'ON' : 'OFF'}
                </button>
              </div>

              <div className="absolute top-6 right-6 flex gap-2 z-30">
                 <button onClick={() => setIsMusicEnabled(!isMusicEnabled)} className={`h-11 w-11 flex items-center justify-center backdrop-blur-xl border rounded-2xl transition-all ${isMusicEnabled ? 'bg-[var(--accent-primary)]/10 text-[var(--accent-primary)] border-[var(--accent-primary)]' : 'bg-[var(--bg-glass)] border-[var(--border-strong)] text-[var(--text-secondary)]'}`} title="Música Techno"><i className={`fa ${isMusicEnabled ? 'fa-volume-up' : 'fa-volume-off'}`}></i></button>
                 <button onClick={toggleTheme} className="h-11 w-11 flex items-center justify-center bg-[var(--bg-glass)] border border-[var(--border-strong)] rounded-2xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all" title="Tema"><i className={`fa ${theme === 'dark' ? 'fa-sun-o' : 'fa-moon-o'}`}></i></button>
                 <button onClick={cyclePalette} className="h-11 w-11 flex items-center justify-center bg-[var(--bg-glass)] border border-[var(--border-strong)] rounded-2xl text-[var(--accent-primary)] hover:text-[var(--text-primary)] transition-all" title="Paleta"><i className="fa fa-paint-brush"></i></button>
                 <button onClick={() => colorInputRef.current?.click()} className={`h-11 w-11 flex items-center justify-center bg-[var(--bg-glass)] border border-[var(--border-strong)] rounded-2xl text-[var(--text-secondary)] transition-all ${palette === 'custom' ? 'text-[var(--accent-primary)]' : ''}`} title="Color"><i className="fa fa-eyedropper"></i></button>
                 <button onClick={() => setShowZones(!showZones)} className={`h-11 w-11 flex items-center justify-center backdrop-blur-xl border rounded-2xl transition-all ${showZones ? 'bg-[var(--accent-primary)]/10 text-[var(--accent-primary)] border-[var(--accent-primary)]' : 'bg-[var(--bg-glass)] border-[var(--border-strong)] text-[var(--text-secondary)]'}`} title="Zonas"><i className="fa fa-hand-paper-o"></i></button>
              </div>

              <div className="absolute top-6 left-1/2 -translate-x-1/2 h-11 w-[400px] bg-[var(--bg-glass)] border border-[var(--border-strong)] rounded-2xl flex items-center px-4 overflow-hidden shadow-2xl z-20 transition-all duration-500" style={{ boxShadow: combo > 15 ? `0 0 30px ${hexToRgba(customColor, 0.3)}` : 'none' }}>
                 <CompactSineWave active={startTime !== null && !isFinished} combo={combo} wpm={stats.wpm} />
                 <div className="flex items-center gap-4 relative z-10 w-full justify-between">
                    <div className="flex items-baseline gap-1.5"><span className="text-[14px] font-black text-[var(--accent-primary)] font-mono">{stats.wpm}</span><span className="text-[7px] font-bold text-[var(--text-secondary)] uppercase">WPM</span></div>
                    <div className="h-4 w-[1px] bg-[var(--border-strong)]" />
                    <div className="flex items-baseline gap-1.5"><span className="text-[14px] font-black text-[var(--text-primary)] font-mono">{stats.accuracy}</span><span className="text-[7px] font-bold text-[var(--text-secondary)] uppercase">%ACC</span></div>
                    <div className="h-4 w-[1px] bg-[var(--border-strong)]" />
                    <div className="flex items-baseline gap-1.5 group">
                      <span className={`text-[14px] font-black font-mono transition-all duration-300 ${combo > 0 ? 'text-[var(--accent-primary)] scale-125' : 'text-[var(--text-muted)]'}`}>
                        {combo}
                      </span>
                      <span className="text-[7px] font-bold text-[var(--text-secondary)] uppercase">COMBO</span>
                    </div>
                    <div className="h-4 w-[1px] bg-[var(--border-strong)]" />
                    <div className="flex items-center gap-1 opacity-40"><div className="w-1.5 h-1.5 rounded-full bg-[var(--accent-primary)] animate-pulse"></div><span className="text-[6px] font-black text-[var(--text-secondary)] uppercase">LIVE</span></div>
                 </div>
              </div>

              <div className="flex justify-center w-full">
                {keyboardType === 'standard' 
                  ? <Keyboard activeKey={activeKey} targetKey={targetChar} showZones={showZones} /> 
                  : <MacKeyboard activeKey={activeKey} targetKey={targetChar} showZones={showZones} />
                }
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-6 right-8 text-[var(--text-secondary)] text-[8px] font-black uppercase tracking-[0.5em] font-mono opacity-20">ALPINE_ECODECOR_PRO // 2025</footer>
    </div>
  );
};

export default App;