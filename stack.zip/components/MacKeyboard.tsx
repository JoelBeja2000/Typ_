import React from 'react';
import { KEY_TO_FINGER_MAP, FINGER_COLORS } from '../constants';

interface MacKeyboardProps {
  activeKey: string;
  targetKey: string;
  showZones?: boolean;
}

const MacKeyboard: React.FC<MacKeyboardProps> = ({ activeKey, targetKey, showZones = false }) => {
  const isKeyActive = (key: string) => activeKey.toLowerCase() === key.toLowerCase();
  
  const normalize = (str: string) => {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  };

  const isKeyTarget = (key: string) => {
    const lowerKey = key.toLowerCase();
    const lowerTarget = targetKey.toLowerCase();
    const normalizedTarget = normalize(targetKey);

    if (lowerKey === 'space' && targetKey === ' ') return true;
    if (lowerKey === 'enter' && (targetKey === 'enter' || targetKey === 'return')) return true;
    
    // Normalización básica
    if (lowerKey === normalizedTarget) return true;

    // Mapeo exhaustivo de símbolos para distribución ISO Español
    const symbols: Record<string, string[]> = {
      'º': ['º', '\\', 'ª'],
      '1': ['1', '!', '|'],
      '2': ['2', '"', '@'],
      '3': ['3', '·', '#'],
      '4': ['4', '$', '~'],
      '5': ['5', '%', '€'],
      '6': ['6', '&', '¬'],
      '7': ['7', '/'],
      '8': ['8', '('],
      '9': ['9', ')'],
      '0': ['0', '='],
      "'": ["'", '?', '"'], 
      '¡': ['¡', '¿'],
      '<': ['<', '>'],
      // Tecla tras P: Acento grave (`), Circunflejo (^) y Corchete apertura ([)
      '[': ['[', '^', '`'], 
      // Tecla tras la anterior: Más (+), Asterisco (*) y Corchete cierre (])
      ']': [']', '*', '+'], 
      // Tecla tras Ñ: Acento agudo (´), Diéresis (¨) y Llave apertura ({)
      '{': ['{', '¨', '´'], 
      // Tecla tras la anterior: Cedilla (ç), Llave cierre (}) y Ç
      '}': ['}', 'ç', 'Ç'],
      ',': [',', ';'],
      '.': ['.', ':'],
      '-': ['-', '_'],
    };

    if (symbols[lowerKey]) {
      return symbols[lowerKey].includes(targetKey) || lowerKey === lowerTarget;
    }
    
    return lowerKey === lowerTarget;
  };

  const getFingerColor = (key: string) => {
    let k = key.toLowerCase();
    
    // Teclas de sistema y modificadores
    if (k === 'tab' || k === 'capslock' || k === 'shift' || k === 'control' || k === 'fn') return FINGER_COLORS['left-pinky'];
    if (k === 'enter' || k === 'backspace') return FINGER_COLORS['right-pinky'];
    if (k === 'space') return FINGER_COLORS['thumb'];
    if (k === 'alt' || k === 'meta') return FINGER_COLORS['thumb'];
    
    // Asignación explícita para la zona derecha ISO (todo al meñique derecho)
    // Esto cubre las teclas de acentos, corchetes, más, ç, etc.
    if (['[', ']', '{', '}', "'", '¡', '+', '*', 'ç', '´', '`', '^', '¨'].includes(k)) {
        return FINGER_COLORS['right-pinky'];
    }

    const data = KEY_TO_FINGER_MAP[k];
    if (data) return FINGER_COLORS[data.finger];
    
    return null;
  };

  const getKeyStyle = (key: string, widthClass: string = 'w-[44px]', heightClass: string = 'h-[44px]') => {
    const active = isKeyActive(key);
    const target = isKeyTarget(key);
    
    let baseClass = `flex flex-col items-center justify-center rounded-[6px] text-[11px] font-medium transition-all duration-100 border relative `;
    
    let extraStyle = {};

    if (active) {
      // Estilo Outline con Glow y Transparencia
      baseClass += `bg-[var(--accent-primary)]/20 border-[var(--accent-primary)] text-[var(--accent-primary)] translate-y-[1px] shadow-[0_0_20px_var(--accent-glow)] `;
    } else if (target) {
      baseClass += `border-[var(--accent-primary)] bg-[var(--key-target-bg)] text-[var(--text-primary)] shadow-[0_0_15px_var(--accent-glow)] animate-pulse `;
    } else if (showZones) {
       const fingerColor = getFingerColor(key);
       if (fingerColor) {
         baseClass += `bg-opacity-10 `;
         extraStyle = {
           borderColor: fingerColor,
           color: fingerColor,
           backgroundColor: `${fingerColor}10`, 
           boxShadow: `0 0 8px ${fingerColor}20` 
         };
       } else {
         baseClass += `bg-[var(--key-bg)] border-[var(--border-glass)] text-[var(--key-text)] shadow-[0_2px_0_var(--key-shadow)] `;
       }
    } else {
      baseClass += `bg-[var(--key-bg)] border-b-2 border-[var(--border-glass)] text-[var(--key-text)] shadow-[0_2px_0_var(--key-shadow)] `;
    }

    return { className: `${baseClass} ${widthClass} ${heightClass}`, style: extraStyle };
  };

  const K = ({k, w, h, children}: {k: string, w?: string, h?: string, children?: React.ReactNode}) => {
     const s = getKeyStyle(k, w, h);
     return <div className={s.className} style={s.style}>{children}</div>
  };

  // Helper para 3 símbolos (ISO Style): Top(Shift) & Bottom(Normal) Centrados, Right(AltGr) Abajo-Derecha
  const IsoKey = ({ top, bottom, right }: { top: string, bottom: string, right: string }) => (
    <div className="w-full h-full relative">
      <div className="flex flex-col items-center justify-center h-full w-full pt-1">
        <span className="text-[10px] leading-none opacity-80 font-medium mb-0.5">{top}</span>
        <span className="text-[13px] font-bold leading-none">{bottom}</span>
      </div>
      <span className="absolute bottom-[4px] right-[4px] text-[10px] opacity-70 leading-none font-medium">{right}</span>
    </div>
  );

  // Helper específico para la tecla Ç (Letra centrada + Símbolo AltGr)
  const LetterKey = ({ l, s }: { l: string, s: string }) => (
    <div className="w-full h-full relative">
       <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-[12px] font-medium">{l}</span>
       </div>
       <span className="absolute bottom-[4px] right-[5px] text-[11px] opacity-70 leading-none font-medium">{s}</span>
    </div>
  );

  // Helper para 2 símbolos estándar (Shift arriba, Normal abajo)
  const DualKey = ({ t, b }: { t: string, b: string }) => (
    <div className="flex flex-col items-center justify-center">
        <span className="text-[10px] opacity-70 mb-[-2px]">{t}</span>
        <span className="text-[12px] font-bold">{b}</span>
    </div>
  );

  const functionKeys = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'];

  return (
    <div className="scale-[0.55] md:scale-[0.75] lg:scale-[0.85] xl:scale-[0.95] origin-center flex justify-center select-none">
      <div className="bg-transparent rounded-[10px] p-1 flex flex-col gap-[6px] w-[755px]">
        
        {/* Touchbar */}
        <div className="flex gap-[1px] items-center mb-1">
          <div className="h-[30px] w-[60px] bg-[var(--key-bg)] rounded text-[9px] text-[var(--key-text)] flex items-center justify-center">esc</div>
          <div className="h-[30px] flex-grow bg-[var(--bg-app)] rounded flex items-center justify-around px-2">
            {functionKeys.map(f => (
              <div key={f} className="text-[8px] font-bold text-[var(--text-secondary)]">{f}</div>
            ))}
          </div>
          <div className="h-[30px] w-[40px] bg-[var(--key-bg)] rounded flex items-center justify-center text-[var(--key-text)]"><i className="fa fa-volume-up text-[10px]"></i></div>
        </div>

        {/* Fila 1 - Números */}
        <div className="flex gap-[6px]">
          <K k="º"><IsoKey top="ª" bottom="º" right="\" /></K>
          <K k="1"><IsoKey top="!" bottom="1" right="|" /></K>
          <K k="2"><IsoKey top='"' bottom="2" right="@" /></K>
          <K k="3"><IsoKey top="·" bottom="3" right="#" /></K>
          <K k="4"><IsoKey top="$" bottom="4" right="~" /></K>
          <K k="5"><IsoKey top="%" bottom="5" right="€" /></K>
          <K k="6"><IsoKey top="&" bottom="6" right="¬" /></K>
          <K k="7"><DualKey t="/" b="7" /></K>
          <K k="8"><DualKey t="(" b="8" /></K>
          <K k="9"><DualKey t=")" b="9" /></K>
          <K k="0"><DualKey t="=" b="0" /></K>
          <K k="'"><DualKey t="?" b="'" /></K>
          <K k="¡"><DualKey t="¿" b="¡" /></K>
          <K k="backspace" w="flex-grow">⌫</K>
        </div>

        {/* Filas 2 y 3 con Enter Vertical ISO */}
        <div className="flex gap-[6px] items-start w-full">
          <div className="flex flex-col gap-[6px] flex-grow-0">
            {/* Fila 2 - QWERTY */}
            <div className="flex flex-row gap-[6px]">
              <K k="tab" w="w-[68px]">⇥</K>
              <K k="q">Q</K>
              <K k="w">W</K>
              <K k="e">E</K>
              <K k="r">R</K>
              <K k="t">T</K>
              <K k="y">Y</K>
              <K k="u">U</K>
              <K k="i">I</K>
              <K k="o">O</K>
              <K k="p">P</K>
              {/* Tecla ISO: ^ (shift/top), ` (normal/bottom-left), [ (altgr/bottom-right) */}
              <K k="["><IsoKey top="^" bottom="`" right="[" /></K>
              {/* Tecla ISO: * (shift/top), + (normal/bottom-left), ] (altgr/bottom-right) */}
              <K k="]"><IsoKey top="*" bottom="+" right="]" /></K>
            </div>
            {/* Fila 3 - ASDFG */}
            <div className="flex flex-row gap-[6px]">
              <div className={`${getKeyStyle('capslock', 'w-[80px]').className} relative`} style={getKeyStyle('capslock').style}>
                <div className={`w-1 h-1 rounded-full bg-green-500 absolute top-2 left-2 ${isKeyActive('capslock') ? 'opacity-100' : 'opacity-0'}`}></div>
                ⇪
              </div>
              <K k="a">A</K>
              <K k="s">S</K>
              <K k="d">D</K>
              <K k="f">F</K>
              <K k="g">G</K>
              <K k="h">H</K>
              <K k="j">J</K>
              <K k="k">K</K>
              <K k="l">L</K>
              <K k="ñ">Ñ</K>
              {/* Tecla ISO: ¨ (shift/top), ´ (normal/bottom-left), { (altgr/bottom-right) */}
              <K k="{"><IsoKey top="¨" bottom="´" right="{" /></K>
              {/* Tecla ISO: Ç (centrada), } (altgr/bottom-right) */}
              <K k="}"><LetterKey l="Ç" s="}" /></K>
            </div>
          </div>
          {/* Enter Vertical ISO */}
          <div className={`${getKeyStyle('enter', 'w-[52px]', 'h-[94px]').className} flex-col !justify-end pb-4`} style={getKeyStyle('enter').style}>
             <span className="text-xl opacity-70 mb-2">↵</span>
          </div>
        </div>

        {/* Fila 4 - ZXCV */}
        <div className="flex gap-[6px]">
          <K k="shift" w="w-[56px]">⇧</K>
          <K k="<"><DualKey t=">" b="<" /></K>
          <K k="z">Z</K>
          <K k="x">X</K>
          <K k="c">C</K>
          <K k="v">V</K>
          <K k="b">B</K>
          <K k="n">N</K>
          <K k="m">M</K>
          <K k=","><DualKey t=";" b="," /></K>
          <K k="."><DualKey t=":" b="." /></K>
          <K k="-"><DualKey t="_" b="-" /></K>
          <K k="shift" w="flex-grow">⇧</K>
        </div>

        {/* Fila 5 - Espacio */}
        <div className="flex gap-[6px]">
          <K k="fn">fn</K>
          <K k="control">⌃</K>
          <K k="alt" w="w-[54px]">⌥</K>
          <K k="meta" w="w-[64px]">⌘</K>
          <K k="space" w="w-[250px]">{''}</K>
          <K k="meta" w="w-[64px]">⌘</K>
          <K k="alt" w="w-[54px]">⌥</K>
          <div className="flex flex-col justify-end h-[44px] w-[44px]">
            <K k="arrowleft" w="w-full" h="h-[21px]"><i className="fa fa-caret-left"></i></K>
          </div>
          <div className="flex flex-col gap-[2px] w-[44px]">
            <K k="arrowup" w="w-full" h="h-[21px]"><i className="fa fa-caret-up"></i></K>
            <K k="arrowdown" w="w-full" h="h-[21px]"><i className="fa fa-caret-down"></i></K>
          </div>
          <div className="flex flex-col justify-end h-[44px] w-[44px]">
            <K k="arrowright" w="w-full" h="h-[21px]"><i className="fa fa-caret-right"></i></K>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MacKeyboard;